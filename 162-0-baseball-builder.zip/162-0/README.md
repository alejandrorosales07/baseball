# 162&ndash;0 &mdash; Baseball Builder

An all-time baseball roster-building game in the spirit of **82-0** (NBA) and **7-0** (World Cup): spin a random team and decade, draft an eligible player into an open roster spot, and after all 11 spots are filled, see whether your lineup can survive a simulated 162-game MLB season.

This is an independent, fan-made project for entertainment purposes. It is not affiliated with MLB, the MLBPA, or any team. Player stats are approximate, decade-representative figures compiled for gameplay &mdash; not exact single-season box scores.

## How to run it

No build step or server required. Just open `index.html` in a browser, or serve the folder with any static file server:

```bash
cd 162-0
python3 -m http.server 8000
# then visit http://localhost:8000
```

To host it for others, drag the folder into a static host (GitHub Pages, Netlify, Vercel, Cloudflare Pages, etc.) and point it at `index.html`.

## How the game works

1. **11 rounds, 11 decades.** Each round of the draft is locked to a specific decade (1920s&ndash;2020s), shuffled once at the start of the game so every decade is used exactly once.
2. **The reel spins a team.** Within that decade, a random MLB team is selected (only from teams that have at least one player eligible for your remaining open roster spots).
3. **You draft a player into an open slot.** Roster: C, 1B, 2B, 3B, SS, LF, CF, RF, DH, SP, CL. Outfielders can fill any of LF/CF/RF; any batter can fill DH.
4. **Skips.** You get one "re-spin team" (rerolls the team within the same decade) and one "swap era" (trades this round's decade for a different unused one) per game.
5. **The simulation engine** era-adjusts every stat line against that decade's league-average baseline, blends a team-wide average with a "weakest link" penalty (one glaring hole caps your ceiling, just like the games that inspired this one), and runs the result through a non-linear win curve to produce a final record out of 162, a letter grade, your best pick, and your biggest weakness.

Random drafting averages out to roughly a .500 season &mdash; deliberate, era-aware picks (and avoiding a dead slot) are what push a roster toward the top of the curve. A literal 162&ndash;0 season is intentionally out of reach; the engine caps out in the mid-150s for even a near-optimal lineup.

## Project structure

```
162-0/
├── index.html          Entry point
├── css/
│   └── styles.css      Design system (ballpark scoreboard aesthetic)
├── js/
│   ├── data.js         Roster slots, era baselines, and the player database
│   ├── game.js         Draft state machine, eligibility rules, simulation engine
│   └── main.js         UI rendering and event wiring
└── README.md
```

## Extending the player database

All player and team data lives in `js/data.js`. To add a player, find the relevant decade and team in the `TEAMS` object and add an entry:

```js
{ name: "Player Name", pos: "SS", batting: { avg: .300, hr: 20, rbi: 80, ops: .850, sb: 10 } }
```

Position tags: `C`, `1B`, `2B`, `3B`, `SS`, `OF` (fills LF/CF/RF/DH), `DH`, `SP`, `RP` (fills the Closer slot).

Pitchers use a `pitching` object instead of `batting`:

```js
{ name: "Pitcher Name", pos: "SP", pitching: { era: 3.00, w: 18, k9: 8.5, whip: 1.10, sv: 1 } }
```

To add a new decade or adjust the league-average baselines used for era adjustment, edit the `ERA_BASELINES` object at the top of the same file.

## Notes

- No external runtime dependencies. Fonts load from Google Fonts via the `@import` in `styles.css`; everything else is plain HTML/CSS/JS.
- No build tooling, bundler, or framework required.
